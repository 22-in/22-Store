import urllib.request
import urllib.error
import json
from typing import List, Dict, Union, Optional, Generator

_API_KEY: Optional[str] = None

def configure(api_key: str) -> None:
    """Gemini API setup karne ke liye."""
    global _API_KEY
    _API_KEY = api_key

class GenerateContentResponse:
    def __init__(self, text: str):
        self.text = text

class ChatSession:
    def __init__(self, model, history: Optional[List[Dict]] = None):
        self.model = model
        self.history: List[Dict] = history or []

    def send_message(self, text: str, stream: bool = False) -> Union[GenerateContentResponse, Generator[GenerateContentResponse, None, None]]:
        self.history.append({"role": "user", "parts": [{"text": text}]})
        
        if stream:
            response_gen = self.model._generate(self.history, stream=True)
            def stream_generator():
                full_text = ""
                for chunk in response_gen:
                    full_text += chunk.text
                    yield chunk
                self.history.append({"role": "model", "parts": [{"text": full_text}]})
            return stream_generator()
        else:
            response = self.model._generate(self.history, stream=False)
            self.history.append({"role": "model", "parts": [{"text": response.text}]})
            return response

class GenerativeModel:
    def __init__(self, model_name: str, system_instruction: Optional[str] = None):
        # Jaise "gemini-1.5-flash"
        self.model_name = model_name
        self.system_instruction = system_instruction

    def _build_payload(self, contents: List[Dict]) -> Dict:
        payload = {"contents": contents}
        if self.system_instruction:
            payload["systemInstruction"] = {
                "role": "system",
                "parts": [{"text": self.system_instruction}]
            }
        return payload

    def generate_content(self, prompt: Union[str, List[Dict]], stream: bool = False) -> Union[GenerateContentResponse, Generator[GenerateContentResponse, None, None]]:
        if isinstance(prompt, str):
            contents = [{"role": "user", "parts": [{"text": prompt}]}]
        else:
            contents = prompt
        return self._generate(contents, stream)

    def _generate(self, contents: List[Dict], stream: bool):
        if not _API_KEY:
            raise ValueError("API Key missing hai! Pehle google_generativeai.configure(api_key='YOUR_KEY') call karo.")

        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model_name}"
        if stream:
            url += f":streamGenerateContent?alt=sse&key={_API_KEY}"
        else:
            url += f":generateContent?key={_API_KEY}"

        payload = self._build_payload(contents)
        data_bytes = json.dumps(payload).encode('utf-8')
        
        req = urllib.request.Request(url, data=data_bytes, headers={'Content-Type': 'application/json'})

        try:
            response = urllib.request.urlopen(req)
            if stream:
                return self._handle_stream(response)
            else:
                response_data = json.loads(response.read().decode('utf-8'))
                try:
                    text = response_data['candidates'][0]['content']['parts'][0]['text']
                except (KeyError, IndexError):
                    text = "" # Safe fallback agar API ne block kiya
                return GenerateContentResponse(text)
                
        except urllib.error.HTTPError as e:
            error_msg = e.read().decode('utf-8')
            raise RuntimeError(f"Gemini API Error (Code: {e.code}): {error_msg}")

    def _handle_stream(self, response) -> Generator[GenerateContentResponse, None, None]:
        for line in response:
            decoded_line = line.decode('utf-8').strip()
            if decoded_line.startswith("data: "):
                data_str = decoded_line[6:]
                if data_str == "[DONE]":
                    break
                try:
                    data = json.loads(data_str)
                    text = data['candidates'][0]['content']['parts'][0]['text']
                    yield GenerateContentResponse(text)
                except (json.JSONDecodeError, KeyError, IndexError):
                    continue

    def start_chat(self, history: Optional[List[Dict]] = None) -> ChatSession:
        return ChatSession(self, history)